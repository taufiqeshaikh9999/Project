<!-- footer -->
<div class="row justify-content-center text-white" id="footer">

  <div class="col-md-3 col-11" >
    <h4>About</h4>
    <a href="#">Best In Industry</a><br>
    <a href="#">Special Care</a><br>
    <a href="#">Brand guideline</a><br>
    <a href="#">Term and conditions</a><br>
    <a href="#">Privacy policy</a><br>
  </div>
  <div class="col-md-3 col-11">
    <h4>services</h4>
    <a href="">Pet Boarding</a><br>
    <a href="">Pet Feeding</a><br>
    <a href="">Pet Grooming</a><br>
    <a href="">Per Training</a><br>
    <a href="">Pet Exercise</a><br>
  </div>
  <div class="col-md-4  col-12" style="margin-left: 2px;">
    <!-- <h4 style="margin-right: 208px; margin-top: 2px; margin-bottom: 14px;">Get In Touch</h4> -->
    <!-- <p>Get In Touch</p> -->
    <!-- <form action=""  id="footer-form">
              <input type="text" id="footer-search-box">
              <button type="submit" id="footer-search-submit"><i class="bi bi-cursor-fill"></i></button>
            </form> -->
    <!-- <form id="footer-form" class="d-flex flex-nowrap justify-content-md-end justify-content-center">
      <input  id="footer-search-box" class="form-control me-2" placeholder="Search" type="search">
      <button  id="footer-search-submit" class="btn btn-info" >
        <i class="bi bi-cursor-fill"></i>
      </button>
    </form> -->


    <!--    
      
      <p style="margin-right: 134px;"><i class="fa fa-map-marker-alt mr-2"></i>123 Street, New York, USA</p>
      <p style="margin-right: 196px;"><i class="fa fa-phone-alt mr-2"></i>+012 345 67890</p>
      <p style="margin-right: 174px;"><i class="fa fa-envelope mr-2"></i>info@example.com</p>
       -->




    <!-- <div class="col-md-2 col-11"> -->
    <h4>Get In Touch</h4>
    <a href=""><i class="fa fa-map-marker-alt mr-2"></i>priya colony padegaon aurangabd India</a><br>
    <a href=""><i class="fa fa-phone-alt mr-2"></i>+91 8788725267</a><br>
    <a href=""><i class="fa fa-envelope mr-2"></i>taufiqeshaikh@9999gmail.com</a><br>

    <div style="margin-top: 34px; margin-left: -17px;">
      <i class="bi bi-instagram social-icon"></i>
      <i class="bi bi-facebook  social-icon"></i>
      <!-- <i class="bi bi-twitter   social-icon"></i> -->
      <i class="bi bi-whatsapp  social-icon"></i>
    </div>
  </div>




</div>
</div>




<!-- container fluid end -->

</div>









<!-- 
    
    x-small               0px - 575px       [col-*]     col-12
    small                 576px - 776px     [col-sm-*]
    medium                768px - 991px     [col-md-*] col-md-7
    large                 992px - 1199px    [col-lg-*]
    Extra large           1200px - 1399px   [col-xl-*]
    Extra extra large     1400px - 1399px   [col-xxl-*]
    
    -->

<!-- Option 1: Bootstrap Bundle with Popper -->
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script> -->
<script src="./bootstrap/js/bootstrap.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>



<!-- Back to Top -->
<!-- <button href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></button> -->


<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/tempusdominus/js/moment.min.js"></script>
<script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
<script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>



<!-- Template Javascript -->
<script src="js/main.js"></script>




</body>

</html>