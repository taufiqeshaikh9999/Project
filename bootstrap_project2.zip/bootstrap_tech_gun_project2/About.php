<!doctype html>
<html lang="en">



<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
  <link rel="stylesheet" href="./bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="./style2.css">
  <!-- bootstrap icon -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="./style2.css">


  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon">

<!-- Google Web Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet"> 

<!-- Font Awesome -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

<!-- Flaticon Font -->
<link href="lib/flaticon/font/flaticon.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

<!-- Customized Bootstrap Stylesheet -->   
 <!-- Hover on header buttons cdn -->
<link href="css/style.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>


  <title>project 2</title>
  <style>
   
  </style>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark  sticky-top " id="top_nav">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="./dog.jpg" style="height: 69px; width: 80px; margin-left: 24px;">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 gap-2" style="font-size: 20px; padding-left: 18px;">
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="project_2.php" class="color">Home</a>
          </li>
          <li class="nav-item gap-2">
            <a class="nav-link active" href="About.php" class="color">About</a>
          </li>

          <li class="nav-item gap-2">
            <a class="nav-link " href="Service.php" class="color">Service</a>
          </li>

          <li class="nav-item gap-2">
            <a class="nav-link" href="Contact.php" class="color">Contact</a>
          </li>
        
        </ul>
        <form class="d-flex" id="searchform">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" id="searchbox">
          <button class="btn btn-outline-success" type="submit" id="searchbtn"><i class="bi bi-search"></i></button>
        </form>
      </div>
    </div>
  </nav>


<div class="container py-5">
    <!-- About Us -->
    <div class="container py-5">
        <div class="row py-5">
            <div class="col-lg-7 pb-5 pb-lg-0 px-3 px-lg-5">
                <h4 class="text-secondary mb-3">About Us</h4>
                <h1 class="display-4 mb-4"><span class="text-primary">Boarding</span> & <span class="text-secondary">Daycare</span></h1>
                <h5 class="text-muted mb-3">Boarding & Daycare ensures your pet feels at home while you're away. We provide a safe, fun, and caring environment for their comfort and joy.</h5>
                <p class="mb-4">Our trained staff offers personalized attention and regular playtime. Your pet stays happy, healthy, and loved every single day.</p>
                <ul class="list-inline">
                    <li><h5><i class="fa fa-check-double text-secondary mr-3"></i>Best In Industry</h5></li>
                    <li><h5><i class="fa fa-check-double text-secondary mr-3"></i>Emergency Services</h5></li>
                    <li><h5><i class="fa fa-check-double text-secondary mr-3"></i>24/7 Customer Support</h5></li>
                </ul>
                <a href="" class="btn btn-lg btn-primary mt-3 px-4">Learn More</a>
            </div>
            <div class="col-lg-5">
                <div class="row px-3">
                    <div class="col-12 p-0">
                        <img class="img-fluids w-100" src="cat-2.jpg" alt="">
                    </div>
                    <div class="col-6 p-0">
                        <img class="img-fluids w-100" src="cat-3.jpg" alt="">
                    </div>
                    <div class="col-6 p-0">
                        <img class="img-fluids w-100" src="catA.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>


      
    <!-- Features Start -->
    <div class="container-fluid bg-light">
        <div class="container"  style="background-color: #fcc302;">
            <div class="row align-items-center">
                <div class="col-lg-5">
                    <img class="img-fluids w-100" src="catB.jpg" alt="">
                </div>
                <div class="col-lg-7 py-5 py-lg-0 px-3 px-lg-5">
                    <h4 class="text-secondary mb-3">Why Choose Us?</h4>
                    <h1 class="display-4 mb-4"><span class="text-primary">Special Care</span> On Pets</h1>
                    <p class="mb-4">We provide gentle, expert care to ensure your pet feels safe, happy, and loved every moment.</p>
                    <div class="row py-2">
                        <div class="col-6">
                            <div class="d-flex align-items-center mb-4">
                                <h1 class="flaticon-cat font-weight-normal text-secondary m-0 mr-3"></h1>
                                <h5 class="text-truncate m-0">Best In Industry</h5>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center mb-4">
                                <h1 class="flaticon-doctor font-weight-normal text-secondary m-0 mr-3"></h1>
                                <h5 class="text-truncate m-0">Emergency Services</h5>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center">
                                <h1 class="flaticon-care font-weight-normal text-secondary m-0 mr-3"></h1>
                                <h5 class="text-truncate m-0">Special Care</h5>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center">
                                <h1 class="flaticon-dog font-weight-normal text-secondary m-0 mr-3"></h1>
                                <h5 class="text-truncate m-0">Customer Support</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Features End -->

    

    <!-- Team Members -->
    <div class="text-center mb-4">
      <h6 class="" style="color: #00bec9; margin-top: 26px; font-size: 22px;">Team Member</h6>
      <h2>Meet Our <span class="highlight" style="color: #fcc302;">Team Member</span></h2>
    </div>
    <div class="row g-4">
      <div class="col-md-3 col-12 team-member">
        <img src="./cat2.jpg" class="team-img" alt="Mollie Ross">
        <h6 class="name">Mollie Ross</h6>
        <small class="text-muted">Founder & CEO</small>
      </div>
      <div class="col-md-3 col-12 team-member">
        <img src="./cat-2.jpg" class="team-img" alt="Jennifer Page">
        <h6 class="name">Jennifer Page</h6>
        <small class="text-muted">Chef Executive</small>
      </div>
      <div class="col-md-3 col-12 team-member">
        <img src="./cat-3.jpg" class="team-img" alt="Kate Glover">
        <h6 class="name">Kate Glover</h6>
        <small class="text-muted">Doctor</small>
      </div>
      <div class="col-md-3 col-12 team-member">
        <img src="./cat-1.jpg" class="team-img" alt="Lilly Fry">
        <h6 class="name">Lilly Fry</h6>
        <small class="text-muted">Trainer</small>
      </div>
    </div>
  </div>

<?php require("footer.php")?>