
<?php require('header.php'); ?>
  <!-- container fluid -->


  <div class="container-fluid">

    <!-- banner -->
    <div class="row justify-content-center" id="banner">
      <div class="col-md-6 col-11" id="bannertext">
      <h1 style="margin-left: 157px; font-size: 39px;">Best Pet Services</h1>
      <h1>Keep Your Pet Happy <br></h1>
      <p>To keep your pet happy, make sure they get plenty of playtime and daily exercise to stay active and healthy. Feed them a balanced diet and provide clean, fresh water at all times. Most importantly, give them lots of love, attention, and care to build a strong bond and ensure their emotional well-being.</p>
        <button type="button" class="btn" id="banner-btn-1">contact us</button>
        <button type="button" class="btn" id="banner-btn-2">our services</button>
      </div>
      <div class="col-md-4 d-none d-md-block" id="bannerimg">
        <img src="./blackcat.png.png" class="img-fluid">
      </div>
    </div>
     
    <!-- service -->
    <div class="row justify-content-center">
      <div class="col-md-6 col-11" id="service-text">
      
      <h1 style="font-size: 27px; margin-bottom: 35px;">Going for a vacation?</h1> 
        <h1>Book For Your Pet <br> </h1>
        <p>Booking for your pet is easy and ensures their comfort and care when you’re away. Whether it’s a vet visit, grooming session, or a cozy pet boarding, planning ahead helps avoid stress. Always choose trusted services that treat your pet with love and attention.?</p>
        <button type="button" class="btn" id="service-btn">Our Service</button>
      </div>
      <div class="col-md-5 col-11" id="service-img">
        <img src="./black-dog.jpg" class="img-fluid-black" >
      </div>
    </div>


    <!-- counter -->

    <div class="row justify-content-center" id="counter-section">
      <div class="col-md-3 text-center text-white mt-5 mb-3">
        <i class='bx bxs-heart counte' id="counter-icon"></i>
        <h3>
          +1235<br>
          Happy clients
        </h3>
      </div>
      <div class="col-md-3 text-center text-white  mt-5 mb-3">
        <i class='bx bx-plus-medical' id="counter-icon"></i>
        <h3>
          +1235<br>
          Departments
        </h3>
      </div>
      <div class="col-md-3 text-center text-white  mt-5 mb-3">
        <i class='bx bx-injection' id="counter-icon"></i>
        <h3>
          +1235<br>
          Vaccination
        </h3>
      </div>
    </div>

    <!-- blog -->
     <div class="row justify-content-center" id="blog">
      <div class="col-12 text-center ">
           <h3 style="color:black";>Pet Blog</h3>
        <h1 id="blog-title">Updates From Blog</h1>
        <p id="blog-p">Get the latest pet care tips and fun ideas from our blog.  
           stories, and more!.</p>
      </div>


      <div class="col-md-3 col-11">
        <img src="./cat-1.jpg" class="img-fluid" id=img>
        <div  class="article-detail">
          <h4 class="article-title">Safe Surgery Tips<br>for Your Pet.</h4>
          <p  class="article-date">February 09, 2025</p>
          <p class="article-description">Veterinary surgery can feel overwhelming, but knowing what to expect and how to prepare helps.<br></p>
          <p><a href="./project_2.html" class="article-link"></a></p>
        </div>
      </div>

      <div class="col-md-3 col-11">
        <img src="./cat2.jpg" class="img-fluid"  id=img>
        <div class="article-detail">
          <h4  class="article-title">Essential Tips for Pet <br> Surgery Recovery.</h4>
          <p class="article-date">March 06, 2025</p>
          <p  class="article-description">
          Knowing what to do after your pet’s surgery helps reduce stress and ensures a faster, more comfortable recovery.</p>
          <p><a href="./project_2.html" class="article-link"></a></p>
        </div>
      </div>
        
      <div class="col-md-3 col-11">
        <img src="./cat3.jpg" class="img-fluid"  id=img>
        <div  class="article-detail">
          <h4  class="article-title">Helping Your Pet Heal <br>After an Operation.</h4>
          <p class="article-date">April 03, 2025</p>
          <p  class="article-description">
            Supporting your pet after an operation involves rest, love, and close attention to recovery signs.</p>
          <p ><a href="./project_2.html" class="article-link"></a></p>
        </div>
      </div>


      <?php require('footer.php'); ?>

